export default function Login() {
  return (
    <main className="auth">
      <div className="card">
        <div className="brand"><span>AURA</span><b>CAMP</b></div>
        <h1>Welcome back</h1>
        <p>Login to continue to your AURACAMP dashboard.</p>
        <button>Continue with Google</button>
        <div className="or">or</div>
        <input placeholder="Email address" type="email" />
        <button className="primary">Send OTP</button>
        <a href="/">← Back to home</a>
      </div>
    </main>
  );
}